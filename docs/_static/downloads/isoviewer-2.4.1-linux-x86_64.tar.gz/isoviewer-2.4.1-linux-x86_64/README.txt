IsoViewer 2.4.1 for Linux (x86_64)
Basic Genomics AB

IsoViewer builds an interactive HTML report from the results of the BaseCode
IsoQuant Pipeline. The report is a single file that opens in any web browser
and works offline.

Documentation: https://basecode.readthedocs.io/en/latest/isoviewer/


Requirements

  - Linux on 64-bit Intel or AMD processors (x86_64), with glibc 2.17 or newer:
    RHEL, Rocky or AlmaLinux 8 and newer, Debian 10 and newer, Ubuntu 20.04
    and newer
  - about 200 MB free in the temporary folder (/tmp, or the folder
    set in TMPDIR); IsoViewer unpacks itself there while it runs and removes
    the files when it ends

  Python, Docker, internet access and administrator rights are not needed.


Install

  tar -xzf isoviewer-2.4.1-linux-x86_64.tar.gz
  cd isoviewer-2.4.1-linux-x86_64
  ./isoviewer --version

To run it as "isoviewer" from any folder, copy it to a folder on your PATH:

  mkdir -p ~/.local/bin
  cp isoviewer ~/.local/bin/

or, for every user on the machine:

  sudo cp isoviewer /usr/local/bin/


Build a report

Go to the BaseCode folder of a run that has been through the BaseCode IsoQuant
Pipeline, and build:

  cd /path/to/run/BaseCode
  isoviewer build .

This writes <run>_isoviewer_v2.4.1.html into the current folder. Add
-o report.html to choose the file name, and see all options with:

  isoviewer build --help


Files

  isoviewer                 the program
  README.txt                this file
  LICENSE.txt               the licence terms for IsoViewer
  THIRD-PARTY-NOTICES.txt   open-source components in IsoViewer, with their
                            licences
